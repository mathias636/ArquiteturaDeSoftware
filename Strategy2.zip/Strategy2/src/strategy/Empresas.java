 package strategy;

/*
 *
 * Professor Gerson Risso
 */
public enum Empresas {
  ABC,CBA,XPTO;
}
