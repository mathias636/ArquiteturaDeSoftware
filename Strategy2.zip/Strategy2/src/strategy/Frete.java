 

package strategy;

 
/*
 *  Professor Gerson Risso
 *
 */
public interface Frete {
  public double calcFrete(Distancia distancia);
}
