package strategy;

/*
 *  Professor Gerson Risso
 */
public class Distancia {
  private double valor;

    public Distancia(double valor) {
        this.valor = valor;
    }

    public double getValor() {
        return valor;
    }
  
    
}
