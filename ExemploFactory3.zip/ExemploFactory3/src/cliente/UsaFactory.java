

package cliente;

/*
*  Professor Gerson Risso
*/
import factory.*;
public class UsaFactory {
 
    public static void main(String[] args) {
        Fabrica vw=new FabricaVW();
        Carro carro=vw.factoryMethod(ListaCarros.CELTA);
        System.out.println("Modelo:"+carro.getModelo());
        System.out.println("Pre�o:"+carro.getPreco());
    }

}
