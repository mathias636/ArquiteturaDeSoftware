 

package factory;
/*
 *  Professor Gerson Risso
 *
 */
public interface Fabrica {//Creator
  public Carro factoryMethod(ListaCarros carro);
}
