package factory;

/*
 *  Professor Gerson Risso
 *
 */
public interface Carro {//Product

    public String getModelo();

    public double getPreco();
}
