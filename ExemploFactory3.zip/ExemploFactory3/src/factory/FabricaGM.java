package factory;

/*
 *  Professor Gerson Risso
 */
public class FabricaGM implements Fabrica{//ConcreteCreator

    @Override
    public Carro factoryMethod(ListaCarros carro) {
      if(carro.equals(ListaCarros.CELTA)){
        return new Celta("X", 230000);
      }else if(carro.equals(ListaCarros.ONIX)){
        return new Onix("Premier", 20000);
      }
      return null;
    }

}
