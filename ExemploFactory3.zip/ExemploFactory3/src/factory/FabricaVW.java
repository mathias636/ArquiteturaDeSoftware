package factory;

/*
 *  Professor Gerson Risso
 */
public class FabricaVW implements Fabrica{//ConcreteCreator
   
    @Override
    public Carro factoryMethod(ListaCarros carro){
      if(carro.equals(ListaCarros.FOX)){
        return new Fox("CrossFox", 120000);
      }else if(carro.equals(ListaCarros.JETTA)){
        return new Jetta("GLI", 35000);
      }
      return null;
    }
    
}
