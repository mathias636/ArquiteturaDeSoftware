 

package factory;

/*
 *
 * Professor Gerson Risso
 */
public enum ListaCarros {
 FOX,JETTA,CELTA,ONIX;
}
