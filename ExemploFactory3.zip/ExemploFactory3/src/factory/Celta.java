package factory;

/*
 *  Professor Gerson Risso
 */
public class Celta implements Carro{//ConcreteProduct
    private String modelo;
    private double preco;

    public Celta(String modelo, double preco) {
        this.modelo = modelo;
        this.preco = preco;
    }
    
    @Override
    public String getModelo() {
        return modelo;
    }

    @Override
    public double getPreco() {
        return preco;
    }

}
