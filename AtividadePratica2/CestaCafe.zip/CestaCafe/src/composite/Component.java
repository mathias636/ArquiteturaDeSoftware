package composite;

/*
 *  Professor Gerson Risso
 *
 */
public interface Component {

    public double getPreco();
}
